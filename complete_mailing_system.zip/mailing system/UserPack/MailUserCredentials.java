package UserPack;
import java.io.*;
public class MailUserCredentials {
  private String user;
  private String password;


  public MailUserCredentials()
  {
    user="";//enter the user name
    password="";//enter the password
    sessionId="";
  }
  public String getUser()
  {
     return user;
  }
  public void setUser(String user)
  {
    this.user = user;
  }
  public String getPassword()
  {
     return password;
  }
  public void setPassword(String password)
  {
     this.password=password;
  }

}