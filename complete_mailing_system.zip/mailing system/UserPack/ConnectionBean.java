package UserPack;
import javax.mail.*;
import javax.mail.internet.*;
import javax.activation.*;
public class ConnectionBean{

 String Subject[]=new String[50];
 String From[]=new String[50];
 Store store;
 Session session;
 int flag=1;
 java.util.Properties properties;
 public Folder inbox,draft,trash;


 public Store establishConnection(String user, String password)
 {
   try{
    properties = System.getProperties();
    properties.put("webmail.showbiz.com.pk", "false");//here we have to give the address of web server
    session = Session.getInstance(properties, null);
    store = session.getStore("imap");//we can make it impa or pop3 from here
    store.connect("216.40.246.56", user, password);//again the IP address to connect but the user string and psword is must
    }
    catch(NoSuchProviderException exp)
    {
     System.out.println("NoSuchProviderException");

     flag=0;
    }
    catch(MessagingException exp)
    {
     System.out.println("MessagingException");
     flag=0;
    }
    catch(IllegalStateException exp)
    {
      System.out.println("IllegalStateException");
      flag=0;
    }
    return store;
 }
 public Folder setInbox()throws MessagingException, java.io.IOException
 {
   inbox=store.getFolder("INBOX");
   return inbox;
 }
 public Folder setDrafts()throws MessagingException, java.io.IOException
 {
    draft=store.getFolder("DRAFT");

    if(!(draft.exists())){
      draft.create(Folder.HOLDS_MESSAGES);
    }
    return draft;
 }
 public Folder setTrash()throws MessagingException, java.io.IOException
 {
    trash=store.getFolder("TRASH");
    if(!(trash.exists())){
      trash.create(Folder.HOLDS_MESSAGES);
    }
    return trash;
 }
 public int checkLogin()
 {
   if(flag==1){
    return 1;
   }
   return 0;
 }


}





